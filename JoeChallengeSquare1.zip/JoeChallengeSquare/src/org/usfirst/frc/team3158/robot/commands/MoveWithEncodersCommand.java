package org.usfirst.frc.team3158.robot.commands;

import org.usfirst.frc.team3158.robot.Robot;

import edu.wpi.first.wpilibj.command.Command;

/**
 *
 */
public class MoveWithEncodersCommand extends Command {
	double speedOut;
	double revsOut;
    public MoveWithEncodersCommand(double speed, double revs) {
    	requires(Robot.testEnc);
    	speedOut = speed;
    	revsOut = revs;
    	
    }

    // Called just before this Command runs the first time
    protected void initialize() {
    	
    }

    // Called repeatedly when this Command is scheduled to run
    protected void execute() {
    	Robot.testEnc.go(speedOut);
    }

    // Make this return true when this Command no longer needs to run execute()
    protected boolean isFinished() {
        if(Robot.testEnc.getRevs() <= revsOut){
        	return false;
        }return true;
    }

    // Called once after isFinished returns true
    protected void end() {
    	Robot.testEnc.go(0);
    }

    // Called when another command which requires one or more of the same
    // subsystems is scheduled to run
    protected void interrupted() {
    }
}
