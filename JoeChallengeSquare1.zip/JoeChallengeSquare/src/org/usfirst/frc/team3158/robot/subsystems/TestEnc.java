package 
org.usfirst.frc.team3158.robot.subsystems;

import com.ctre.phoenix.motorcontrol.ControlMode;//MOTOR
import com.ctre.phoenix.motorcontrol.can.TalonSRX;//MOTOR
import edu.wpi.first.wpilibj.Encoder;//ENCODER
import edu.wpi.first.wpilibj.command.Subsystem;//RANDOMSTUFF

public class TestEnc extends Subsystem {
	TalonSRX m8;
	Encoder encoder;
    public TestEnc (){
    	m8 = new TalonSRX(8);
    	encoder = new Encoder(9,8);
    }

    public void go(double speed){
    	m8.set(ControlMode.PercentOutput, speed);
    }
    public double getRevs(){
    	return(encoder.getDistance());
    	
    }
    public void initDefaultCommand() {

    }
}

