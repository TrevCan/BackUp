package org.usfirst.frc.team3158.robot.subsystems;

import com.ctre.phoenix.motorcontrol.can.TalonSRX;

import edu.wpi.first.wpilibj.PWMTalonSRX;
import edu.wpi.first.wpilibj.SpeedControllerGroup;
import edu.wpi.first.wpilibj.command.Subsystem;
import edu.wpi.first.wpilibj.drive.DifferentialDrive;

/**
 *
 */
public class Chassis extends Subsystem {

    PWMTalonSRX m1;	PWMTalonSRX m3;
    PWMTalonSRX m2;	PWMTalonSRX m4;
    SpeedControllerGroup mLeft;
    SpeedControllerGroup mRight;
    DifferentialDrive Drive;
    public Chassis(){
    	m1 = new PWMTalonSRX(0);	m3 = new PWMTalonSRX(2);
    	m2 = new PWMTalonSRX(1);	m4 = new PWMTalonSRX(3);
    	mLeft = new SpeedControllerGroup(m1, m2);
    	mRight = new SpeedControllerGroup(m3,m4);
    	Drive = new DifferentialDrive(mLeft, mRight);
    	
    
    }
    public void drive(double left, double right){
    	Drive.tankDrive(left, right);
    	
    }
    public void initDefaultCommand() {    }
    
}

