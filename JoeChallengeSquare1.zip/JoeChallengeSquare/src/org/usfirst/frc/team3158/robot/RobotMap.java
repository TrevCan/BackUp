package org.usfirst.frc.team3158.robot;

public class RobotMap {
	//Chassis
	
	
		public static int frontLeftMotorPort = 1;
		public static int frontRightMotorPort = 3;
		
		public static int backLeftMotorPort = 2;
		public static int backRightMotorPort = 4;
}
