package org.usfirst.frc.team3158.robot;

import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.buttons.JoystickButton;

public class OI {
	public Joystick pilot;
	JoystickButton a;	//a button
	JoystickButton b;	//b button
	
	public OI(){
		
		
		
	}
}
